<?php

namespace App\Http\Livewire\Backend\Components;

use Livewire\Component;

class TopMenu extends Component
{
    public function render()
    {
        return view('livewire.backend.components.top-menu');
    }
}
